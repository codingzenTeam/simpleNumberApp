// Default
export function getHeader() {
    return `<a href="/">Home</a> | <a href="/even">Even</a> | <a href="/odd">Odd</a> | <a href="/prime">Prime</a> | <a href="/composite">Composite</a><br>`
}

export function getFooter() {
    return `<br>`
}